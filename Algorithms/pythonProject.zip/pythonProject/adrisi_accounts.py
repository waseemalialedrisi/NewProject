import sqlite3
from tkinter import*
from tkinter import ttk
from tkinter import messagebox
#import nswaseem
class account:
    def __init__(self,root):
        self.root=root
        self.root.geometry("600x400")
        self.root.title('برنامج المحاسب الالي')
        self.root.configure(background='silver')
        self.root.resizable(False,False)

        self.fram1=Frame(self.root,width='250',height='400',bg='#008B8B')
        self.fram1.place(x=350,y=1)

        self.lable1=Label(self.fram1,text='اسم الحساب',bg='#008B8B')
        self.lable1.place(x=180,y=1)
        self.lable2 = Label(self.fram1, text='رقم الحساب', bg='#008B8B')
        self.lable2.place(x=180, y=30)
        self.lable3 = Label(self.fram1, text='موقع الحساب', bg='#008B8B')
        self.lable3.place(x=180, y=60)
        self.entry1=Entry(self.fram1)
        self.entry1.place(x=1,y=1)
        self.entry2 = Entry(self.fram1)
        self.entry2.place(x=1, y=30)
        self.entry3 = Entry(self.fram1)
        self.entry3.place(x=1, y=60)

        self.butt1 = Button(self.fram1, text='اضافة هذا الحساب', bg='#483D8B', command=self.add_account)
        self.butt1.place(x=140, y=100)
        self.butt2 = Button(self.fram1, text='عرض جميع الحسابات', bg='#483D8B', command=self.fetch_all)
        self.butt2.place(x=10, y=100)

        self.fram2 = Frame(self.root, width='345', height='400', bg='#FF6347')
        self.fram2.place(x=1, y=1)

        self.scrool_x = Scrollbar(self.fram2, orient=HORIZONTAL)
        self.scrool_y = Scrollbar(self.fram2, orient=VERTICAL)

        self.acount_data = ttk.Treeview(self.fram2, columns=('a_name', 'a_num', 'a_loc'))
        self.acount_data.place(x=1, y=1, width=340, height=397)
        self.acount_data['show'] = 'headings'
        self.acount_data.heading('a_name', text='اسم الحساب')
        self.acount_data.heading('a_num', text='رقم الحساب')
        self.acount_data.heading('a_loc', text='موقع الحساب')
        self.acount_data.column('a_name', width=120)
        self.acount_data.column('a_num', width=100)
        self.acount_data.column('a_loc', width=90)

        self.butt3 = Button(self.fram1, text='اضافة بيانات', bg='red', command=self.add_data_to_account)
        self.butt3.place(x=50, y=160)
        self.butt4=Button(self.fram1,text='حذف حساب',bg='green',command=self.delete_account)
        self.butt4.place(x=50, y=190)








        #self.fetch_all()
    def add_account(self):
        name = self.entry1.get()
        num = self.entry2.get()
        loc = self.entry3.get()
        con = sqlite3.connect("account_data.db")
        cur = con.cursor()
        cur.execute(f"insert into t_account values('{name}',{num},'{loc}')")
        cur.execute(f"create table if not exists {name + num}(is_yours integer,on_you integer,details text)")
        con.commit()
        self.fetch_all()
        con.close()



    def fetch_all(self):
        con = sqlite3.connect("account_data.db")
        cur = con.cursor()
        cur.execute("select * from t_account")
        rows = cur.fetchall()
        if len(rows) != 0:
            self.acount_data.delete(*self.acount_data.get_children())
            for row in rows:
                self.acount_data.insert("", END, values=row)
            con.commit()
        con.close()



    def add_data_to_account(self):
        self.root1 = Tk()
        self.root1.geometry("400x500")
        self.root1.configure(background='silver')
        self.root1.resizable(False, False)
        self.root1.title("العمليات الخاصة بالحسابات")
        self.fra1 = Frame(self.root1, width='400', height='200', bg='#CC66FF')
        self.fra1.place(x=1, y=1)
        self.ent1=Entry(self.fra1)
        self.ent1.place(x=270,y=60)
        self.ent2 = Entry(self.fra1)
        self.ent2.place(x=140, y=60)
        self.ent3 = Entry(self.fra1)
        self.ent3.place(x=1, y=60)
        self.ent4 = Entry(self.fra1)
        self.ent4.place(x=270, y=110)
        lable1=Label(self.fra1,text='اسم الحساب',bg='#CC66FF')
        lable1.place(x=295,y=30)
        lable2 = Label(self.fra1, text='رقم الحساب',bg='#CC66FF')
        lable2.place(x=170, y=30)
        lable3 = Label(self.fra1, text='المبلغ',bg='#CC66FF')
        lable3.place(x=45, y=30)
        lable4 = Label(self.fra1, text='التفاصيل',bg='#CC66FF')
        lable4.place(x=300, y=83)
        lable7 = Label(self.fra1, text='لاضافة اي مبلغ الى حسابك يرجى تعبئة الحقول ادناه',bg='#CC66FF')
        lable7.place(x=75, y=1)
        lable8=Label(self.fra1,text='نوع العملية لك او عليك',bg='#CC66FF')
        lable8.place(x=143,y=83)
        lable10 = Label(self.fra1, text='اسم الحساب',bg='#CC66FF')
        lable10.place(x=330, y=176)
        self.entr5=Entry(self.fra1)
        self.entr5.place(x=202,y=176)
        lable11 = Label(self.fra1, text='رقم الحساب',bg='#CC66FF')
        lable11.place(x=132, y=176)
        self.entr6 = Entry(self.fra1)
        self.entr6.place(x=3, y=176)
        lable12 = Label(self.fra1, text='لمعرفة رصيدك املى الحقول في الاسفل ثم اضغط على استعلام',bg='#CC66FF')
        lable12.place(x=80, y=140)


        def add_data_user():
            a_name = self.ent1.get()
            a_num = self.ent2.get()
            a_amount = self.ent3.get()
            a_det = self.ent4.get()
            check=rid1.get()
            if nswaseem.isalpha(self.ent1.get())==1 and nswaseem.isdigit(self.ent2.get())==1:
                con = sqlite3.connect("account_data.db")
                cur = con.cursor()
                cur.execute(f"select a_name,a_num from t_account where a_name='{self.ent1.get()}' and a_num={self.ent2.get()}")
                con.commit()
                N_name = cur.fetchall()
                con.close()
                if N_name.__len__() == 1 and N_name[0].__len__() == 2:
                    if (check=='لك'):
                        con = sqlite3.connect("account_data.db")
                        cur = con.cursor()
                        cur.execute(f"insert into {a_name + a_num} values({a_amount},{0},'{a_det}')")
                        con.commit()
                        fetch_data_account()
                        con.close()
                    elif (check=='عليك'):
                        con = sqlite3.connect("account_data.db")
                        cur = con.cursor()
                        cur.execute(f"insert into {a_name + a_num} values({0},{a_amount},'{a_det}')")
                        con.commit()
                        fetch_data_account()
                        con.close()
                else:
                    messagebox.showerror('Error', f'{self.ent1.get()}عفوا لا يوجد حساب باسم ')
            else:
                messagebox.showerror('Error', 'عفوا يجب عليك ادخال اسم الحساب ورقم الحساب')

        def fetch_data_account():
            if self.entr5.get().__len__() > 0 and self.entr6.get().__len__() > 0:
                con = sqlite3.connect("account_data.db")
                cur = con.cursor()
                cur.execute(f"select a_name,a_num from t_account where a_name='{self.entr5.get()}' and a_num={self.entr6.get()}")
                con.commit()
                N_name = cur.fetchall()
                con.close()
                if N_name.__len__() == 1 and N_name[0].__len__() == 2:
                    con = sqlite3.connect("account_data.db")
                    cur = con.cursor()
                    cur.execute(f"select * from {self.entr5.get() + self.entr6.get()}")
                    rows = cur.fetchall()
                    if len(rows) != 0:
                        self.show_data.delete(*self.show_data.get_children())
                        for row in rows:
                            self.show_data.insert("", END, values=row)
                        con.commit()
                    cur.execute(f"select SUM(is_yours) from {self.entr5.get() + self.entr6.get()}")
                    sumyours = cur.fetchall()
                    con.commit()
                    cur.execute(f"select SUM(on_you) from {self.entr5.get() + self.entr6.get()}")
                    sumyou = cur.fetchall()
                    con.commit()
                    con.close()
                    lable5.config(text=f'{sumyours[0]}الاجمالي لك ', bg='green')
                    lable6.config(text=f'{sumyou[0]}الاجمالي عليك ', bg='red')
                else:
                    messagebox.showerror('Error', f'{self.entr5.get()}عفوا لا يوجد حساب باسم ')
            elif self.ent1.get().__len__() > 0 and self.ent2.get().__len__() > 0:
                con = sqlite3.connect("account_data.db")
                cur = con.cursor()
                cur.execute(f"select a_name,a_num from t_account where a_name='{self.ent1.get()}' and a_num={self.ent2.get()}")
                con.commit()
                N_name = cur.fetchall()
                con.close()
                if N_name.__len__() == 1 and N_name[0].__len__() == 2:
                    con = sqlite3.connect("account_data.db")
                    cur = con.cursor()
                    cur.execute(f"select * from {self.ent1.get() + self.ent2.get()}")
                    rows = cur.fetchall()
                    if len(rows) != 0:
                        self.show_data.delete(*self.show_data.get_children())
                        for row in rows:
                            self.show_data.insert("", END, values=row)
                        con.commit()
                    cur.execute(f"select SUM(is_yours) from {self.ent1.get() + self.ent2.get()}")
                    sumyours = cur.fetchall()
                    con.commit()
                    cur.execute(f"select SUM(on_you) from {self.ent1.get() + self.ent2.get()}")
                    sumyou = cur.fetchall()
                    con.commit()
                    con.close()
                    lable5.config(text=f'{sumyours[0]}الاجمالي لك ', bg='green')
                    lable6.config(text=f'{sumyou[0]}الاجمالي عليك ', bg='red')
                else:
                    messagebox.showerror('Error', f'{self.ent1.get()}عفوا لا يوجد حساب باسم ')
            else:
                messagebox.showerror('Error', 'عفوا يجب عليك ادخال اسم الحساب ورقم الحساب')

        but1 = Button(self.fra1, text='اضافة هذهة العملية', command=add_data_user)
        but1.place(x=10, y=90)
        but2 = Button(self.fra1, text='استعلام',command=fetch_data_account)
        but2.place(x=20, y=140)

        rid1=Entry(self.fra1)
        rid1.place(x=140,y=110)

        self.fra2 = Frame(self.root1, width='395', height='295',bg='#FF8C00')
        self.fra2.place(x=2, y=203)
        lable5 = Label(self.fra2, text='الاجمالي لك ',bg='green')
        lable5.place(x=200, y=272)
        lable6 = Label(self.fra2, text='الاجمالي عليك ',bg='red')
        lable6.place(x=5, y=272)

        self.show_data = ttk.Treeview(self.fra2,columns=('is_your','on_you','a_det'))
        self.show_data['show']= 'headings'
        self.show_data.heading('is_your',text='لك')
        self.show_data.heading('on_you', text='عليك')
        self.show_data.heading('a_det', text='ملاحضة')
        self.show_data.column('is_your', width=120)
        self.show_data.column('on_you', width=100)
        self.show_data.column('a_det', width=100)
        self.show_data.place(x=1,y=1,width=392, height=270)

        self.root1.mainloop()

    def delete_account(self):
        root2=Tk()
        root2.geometry("400x210")
        fr_delete=Frame(root2,width='395', height='200',bg='red')
        fr_delete.place(x=1,y=1)
        dl1=Label(fr_delete,text="إدخل إسم الحساب ",bg="red")
        dl1.place(x=280,y=10)
        dl2 = Label(fr_delete, text="إدخل رقم الحساب ",bg="red")
        dl2.place(x=280, y=60)
        dl3=Label(fr_delete,text="ملاحضة عند حذف الحساب لا يمكنك استرجاعة باي طريقة كانت",bg="red")
        dl3.place(x=50,y=100)
        a_name=Entry(fr_delete)
        a_name.place(x=100,y=10)
        a_num = Entry(fr_delete)
        a_num.place(x=100, y=60)

        def delt():
            xx=a_name.get()
            yy=a_num.get()
            if xx == "":
                messagebox.showerror('خطاء','يجب إدخال إسم الحساب!')
            elif yy == "":
                messagebox.showerror('خطاء','يجب إدخال رقم الحساب!')
            else:
                if  nswaseem.isalpha(xx) == 1 and nswaseem.isdigit(yy) == 1:
                    con=sqlite3.connect("account_data.db")
                    cur=con.cursor()
                    cur.execute(f"delete from {xx + yy}")
                    con.commit()
                    cur.execute(f"drop table {xx + yy}")
                    con.commit()
                    cur.execute(f"delete from t_account where a_name='{xx}' and a_num={yy}")
                    con.commit()
                    self.fetch_all()
                    con.close()
                else:
                    messagebox.showerror('خطاء', 'يجب إدخال قيمة صحيحة لكل حقل')

        but1 = Button(fr_delete, text='حذف الحساب', command=delt,width="50",bg="red")
        but1.place(x=20, y=160)
        root2.mainloop()

root = Tk()
accou = account(root)
root.mainloop()